package com.esliceu.PracticaDrawing2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaDrawing2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
